from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
class HttpRespose:
    ""


def home(request):
    return render(request,'leapyear.html')


def find_leap(request):
    year = int(request.POST['number1'])
    if year % 4 == 0:
        if year % 100 == 0:
            if year % 400 == 0:
                status="leapyear"
            else:
                status="normal year"
        else:
            status = "leapyear"
    else:
        status = "normal year"
    return render(request,"leapyear.html",{'n1':year,"result":status})