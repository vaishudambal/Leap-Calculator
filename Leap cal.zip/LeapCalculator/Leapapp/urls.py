from django.urls import path

from Leapapp import views

urlpatterns = [
    path('',views.home),
    path('findyear',views.find_leap)
]