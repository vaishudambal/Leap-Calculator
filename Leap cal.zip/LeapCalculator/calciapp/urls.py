from django.urls import path

from calciapp import views

urlpatterns = [
    path('',views.home),
    path('result',views.result_fun)
]