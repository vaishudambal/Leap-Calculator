from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'calciapp.html')


def result_fun(request):
    n1 = int(request.POST['number1'])
    n2 = int(request.POST['number2'])
    operation = request.POST['operation']
    result = None
    if operation == 'Add':
        result = n1 + n2
    elif operation=='Sub':
        result = n1 - n2
    elif operation == 'Mul':
        result = n1 * n2
    elif operation == 'Div':
        try:
            result = n1 / n2
        except:
            result='please provide int value for n2'
    result_dict={'n1':n1,'n2':n2,'operation':operation,'result':result}
    return render(request,'calciapp.html',result_dict)